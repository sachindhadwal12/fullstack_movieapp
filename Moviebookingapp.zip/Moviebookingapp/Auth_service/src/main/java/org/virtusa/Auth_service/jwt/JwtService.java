package org.virtusa.Auth_service.jwt;

import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;



import java.security.Key;
import java.time.Instant;
import java.util.Date;

@Component
public class JwtService {
    private final Key signingkey;
    private final long expirationMs;

    public JwtService(@Value("${jwt.secret}") String secret,@Value("${jwt.expiration-ms}") long expirationMs) {
        this.signingkey = Keys.hmacShaKeyFor(secret.getBytes());
        this.expirationMs = expirationMs;
    }
    public String generateToken(String email){
        Instant instant= Instant.now();
        return Jwts.builder()
                .setSubject(email)
                .setIssuedAt(Date.from(instant))
                .setExpiration(new Date(instant.toEpochMilli()+ expirationMs))
                .signWith(signingkey, SignatureAlgorithm.HS256)
                .compact();
    }

    public String extractUsername(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(signingkey)
                .build()
                .parseClaimsJwt(token)
                .getBody()
                .getSubject();
    }

    public boolean isValid(String token){
        try{
            Jwts.parserBuilder().setSigningKey(signingkey).build().parseClaimsJwt(token);
            return true;
        } catch (JwtException jwtException){
            return false;
        }
    }
}
