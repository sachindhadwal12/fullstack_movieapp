package org.virtusa.Auth_service.service;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.virtusa.Auth_service.repository.UserRepository;

@Service
public class AuthService {
private final UserRepository repository;
private final PasswordEncoder encoder;

    public AuthService(UserRepository repository, PasswordEncoder encoder) {
        this.repository = repository;
        this.encoder = encoder;
    }

    public void register(String email, String password){
        if(repository.existsByEmail(email)) {
            throw new IllegalArgumentException("EMail already Exists");
        }
        var user  = User.builder()
                .username(email).
                password(encoder.encode(password))
                .build();
        repository.save(user);
    }
}

