package org.virtusa.Auth_service.jwt;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.virtusa.Auth_service.repository.UserRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {
    private final UserRepository repository;

    public CustomUserDetailsService(UserRepository repository) {
        this.repository = repository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        var u = repository.findByEmail(email)
                .orElseThrow(()-> new RuntimeException("Email not Found "+ email)
                        );
        return User.withUsername(u.getEmail())
                .password(u.getPassword())
                .build();
    }
}
