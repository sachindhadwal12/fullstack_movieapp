package org.virtusa.Auth_service.dto;

public record AuthResponse(String accessToken) {
}
