package org.virtusa.favorite_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FavoriteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
